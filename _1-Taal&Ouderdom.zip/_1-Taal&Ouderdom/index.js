let taal, ouderdom;

taal = "Spaans";
document.write(`<p>De taal is nu: ${taal}</p>`);

taal = "Nederlands";
document.write(`<p>De taal is nu: ${taal}</p>`);

ouderdom = prompt("Hoe oud ben je nu?");
document.write(`<p>Dan wordt je volgend jaar: ${parseInt(ouderdom) + 1}</p>`);