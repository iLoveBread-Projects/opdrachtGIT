// Prompts maken en opslaan als variabelen
const naam = prompt(`Wat is de naam van het tijdschrift?`);
const kostprijs = prompt(`Wat is de kostprijs voor 1 artikel?`);
const aantal = prompt(`Hoeveel wilt u er kopen?`);

// Resultaatzin weergeven
document.write(`U zult ${aantal}x ${naam} kopen, hiervoor betaalt u dan €${parseFloat(kostprijs.replace(',', '.')) * parseFloat(aantal)}`);