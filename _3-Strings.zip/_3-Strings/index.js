// Declare the variables
const voornaam = prompt("Wat is jouw voornaam?") || "";
const naam = prompt("Wat is jouw achternaam") || "";

let fileName = `javaScriptFrameWork`;
let email = `jan.klaassen@mail.com`;
let tekst = `Deze tekst is te lang en zal worden afgekapt op 8 tekens m.b.v. substr().`;
let subTekst = tekst.substr(0, 8);

const atPos = email.search('@');
const atSplit = email.split('@');

// Create sentence variable and write it in the HTML doc
const fullName = `<p>Hallo ${voornaam} ${naam}.</p>`;
document.write(fullName);

// Calculate the full name length (spaces excluded)
const nameLength = `${voornaam.replaceAll(" ", "") + naam.replaceAll(" ", "")}`.length;
document.write(`<p>Je naam bevat ${nameLength} karakters</p>`);

// Create sentence to display the original fileName variable
document.write(`<p>De originele filename is: ${fileName}</p>`);

// Convert all uppercases to lowercases
fileName = fileName.toLowerCase();

// Create sentence to display the new fileName variable
document.write(`<p>De filename kan beter in kleine letters getypt worden, dus: ${fileName}.</p>`);

// Split the fileName variable using the .substring() and .substr() method
const fileName_lastPos = fileName.slice('javascript'.length);
const fileName_firstPos = fileName.replace(fileName_lastPos, "");
document.write(`<p>Als je ${fileName} opsplitst, krijg je: ${fileName_firstPos} en ${fileName_lastPos}.</p>`);

// Create sentence to display the position of the @-sign
document.write(`<p>In ${email} staat de @ op positie: ${atPos}</p>`);

// Create sentence to display the email name
document.write(`<p>De naam is dus: ${atSplit[0]}</p>`);

// Create sentence using the .substr() method
document.write('<p></p>')
document.write(`<p>De originele tekst: ${tekst} wordt dan: ${subTekst}</p>`);